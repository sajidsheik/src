(function () {
    'use strict';

    angular.module('app.service.notify', [
        'app.service.notify.factory',
        'app.service.notify.directive',
        'app.service.notify.formError'
    ])
})();
