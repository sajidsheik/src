(function() {
    'use strict';

    angular.module('app.navigation.leftNavbar', [
        'app.navigation.leftNavbar.directive'
    ]);

})();
