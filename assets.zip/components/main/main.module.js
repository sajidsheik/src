(function () {
    'use strict';

    angular.module('app.main', [
    	 'app.main.patient',
        'app.main.dashboards',
        'app.main.employee',
        'app.main.ledger',
        'app.main.report',
        'ui.bootstrap'

    ])
})();
