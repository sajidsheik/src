(function() {
    'use strict';

    angular.module('app.navigation.topNavbar', [
        'app.navigation.topNavbar.directive'
    ]);
})();
